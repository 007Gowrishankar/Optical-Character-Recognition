# Aadhar-Card-OCR

<h3> This Python code will extract data from your Aadhar Card like ID Number, Date of Birth, Gender and also it extract the photo from Aadhar card.</h3>

Name Extraction is difficult. It will be added in next version.


![Aadhar Card](https://user-images.githubusercontent.com/48207530/83176394-ffccac00-a13a-11ea-9644-75ee77b70ff3.jpg)
![OUTPUT](https://user-images.githubusercontent.com/48207530/80412139-002f1880-88eb-11ea-977d-9bd7d09904cc.PNG)
